$Id$

To get started, read the How-To for this component:
   http://localhost:8888/howto/howto-paginator-transformer.html

For those who don't like to read docs:

Make sure you have a version 2.0.3 or greater of Cocoon. 

To get going with Cocoon 2.0.3, access:
      http://localhost:8080/cocoon/mount/paginator/list(1)

To get going with Cocoon 2.1, access:
      http://localhost:8888/samples/paginator/list(1)


Have fun!
